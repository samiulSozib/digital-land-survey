const base_url="http://localhost:1000"
//const base_url="https://digital-land-survey.soykothosen.com"

module.exports=base_url