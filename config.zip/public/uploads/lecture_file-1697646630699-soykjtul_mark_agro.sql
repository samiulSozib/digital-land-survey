-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Oct 17, 2023 at 12:51 PM
-- Server version: 10.5.20-MariaDB-cll-lve-log
-- PHP Version: 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `soykjtul_mark_agro`
--

-- --------------------------------------------------------

--
-- Table structure for table `extra_cat`
--

CREATE TABLE `extra_cat` (
  `extra_cat_id` int(11) NOT NULL,
  `extra_cat_ref` varchar(255) NOT NULL,
  `extra_cat_name` varchar(255) NOT NULL,
  `extra_cat_image_url` varchar(255) NOT NULL,
  `popular_cat_value` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `extra_cat`
--

INSERT INTO `extra_cat` (`extra_cat_id`, `extra_cat_ref`, `extra_cat_name`, `extra_cat_image_url`, `popular_cat_value`) VALUES
(1, '1', 'testExtraCat', 'test.jpg', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `flashsell`
--

CREATE TABLE `flashsell` (
  `flashSell_id` int(11) NOT NULL,
  `flashSell_image_url` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `flashsell`
--

INSERT INTO `flashsell` (`flashSell_id`, `flashSell_image_url`) VALUES
(1, 'test1.jpg'),
(2, 'test1.jpg'),
(3, 'test2.jpg'),
(4, 'test3.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `main_cat`
--

CREATE TABLE `main_cat` (
  `main_cat_id` int(11) NOT NULL,
  `main_cat_name` varchar(255) NOT NULL,
  `main_cat_image_url` varchar(255) DEFAULT NULL,
  `popular_cat_value` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `main_cat`
--

INSERT INTO `main_cat` (`main_cat_id`, `main_cat_name`, `main_cat_image_url`, `popular_cat_value`) VALUES
(1, 'testMainCat', 'main.jpg', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `order_status` int(11) NOT NULL DEFAULT 1,
  `seller_id` int(11) DEFAULT NULL,
  `placed_date` date DEFAULT NULL,
  `delivery_date` date DEFAULT NULL,
  `in_cart` int(11) NOT NULL DEFAULT 1,
  `is_paid` int(11) NOT NULL DEFAULT 0,
  `deliveryCharge` double DEFAULT 0,
  `address` varchar(250) DEFAULT NULL,
  `return_reason` varchar(250) NOT NULL DEFAULT 'No Reason Said'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `user_id`, `order_status`, `seller_id`, `placed_date`, `delivery_date`, `in_cart`, `is_paid`, `deliveryCharge`, `address`, `return_reason`) VALUES
(1, 1, 1, 1, NULL, NULL, 0, 0, 0, NULL, 'No Reason Said'),
(71, 1, 3, 1, '2023-09-19', '2023-09-26', 0, 0, 0, '{\"division\":\"Rajshahi\",\"district\":\"Rajshahi\",\"thana\":\"Motihar\",\"deliveryNumber\":\"01747090362\",\"areaName\":\"Talaimari\"}', 'No Reason Said'),
(73, 13, 3, 1, '2023-10-09', '2023-10-16', 0, 0, 0, '{\"division\":\"Rajshahi\",\"district\":\"Rajshahi\",\"thana\":\"Motihar\",\"deliveryNumber\":\"01747090362\",\"areaName\":\"Talaimari\"}', 'No Reason Said');

-- --------------------------------------------------------

--
-- Table structure for table `order_details`
--

CREATE TABLE `order_details` (
  `order_details_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_quantity` int(11) NOT NULL,
  `product_total_price` double NOT NULL,
  `note_to_user` varchar(255) DEFAULT NULL,
  `stock_out` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_details`
--

INSERT INTO `order_details` (`order_details_id`, `order_id`, `product_id`, `product_quantity`, `product_total_price`, `note_to_user`, `stock_out`) VALUES
(2, 71, 1, 2, 400, NULL, 0),
(85, 71, 1, 5, 1000, NULL, 0),
(87, 73, 2, 1, 2000, NULL, 0),
(88, 73, 1, 2, 400, NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `payment_method`
--

CREATE TABLE `payment_method` (
  `payment_method_id` int(11) NOT NULL,
  `method_name` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payment_method`
--

INSERT INTO `payment_method` (`payment_method_id`, `method_name`) VALUES
(1, 'Bkash'),
(2, 'Nagad');

-- --------------------------------------------------------

--
-- Table structure for table `payment_types`
--

CREATE TABLE `payment_types` (
  `id` int(11) NOT NULL,
  `type_name` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payment_types`
--

INSERT INTO `payment_types` (`id`, `type_name`) VALUES
(1, 'shop_product'),
(2, 'reference'),
(3, 'withdraw'),
(4, 'sent money');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_price` double NOT NULL,
  `product_short_des` varchar(255) NOT NULL,
  `product_details_des` varchar(255) NOT NULL,
  `product_cat_id` varchar(255) NOT NULL,
  `seller_id` int(11) DEFAULT NULL,
  `sell_count` int(11) DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 2,
  `admin_published` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `product_name`, `product_price`, `product_short_des`, `product_details_des`, `product_cat_id`, `seller_id`, `sell_count`, `quantity`, `status`, `admin_published`) VALUES
(1, 'TestProduct', 200, 't', 'T for Test', '1', 1, 5, 0, 1, 1),
(2, 'test2', 2000, 'dawd', 'adwdawd', '1', 1, NULL, 0, 2, 0);

-- --------------------------------------------------------

--
-- Table structure for table `product_image`
--

CREATE TABLE `product_image` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_image_url` varchar(255) NOT NULL,
  `featured_image` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product_image`
--

INSERT INTO `product_image` (`id`, `product_id`, `product_image_url`, `featured_image`) VALUES
(1, 1, 'test1.jpg', 0),
(2, 1, 'test2.jpg', 1),
(3, 2, 'test1.jpg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `product_video`
--

CREATE TABLE `product_video` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_video_url` varchar(255) NOT NULL,
  `featured_video` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `status`
--

CREATE TABLE `status` (
  `status_id` int(11) NOT NULL,
  `status_name` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `status`
--

INSERT INTO `status` (`status_id`, `status_name`) VALUES
(1, 'Pending'),
(2, 'Confirm'),
(3, 'Processing'),
(4, 'Picked'),
(5, 'Shipped'),
(6, 'Delivered');

-- --------------------------------------------------------

--
-- Table structure for table `sub_cat`
--

CREATE TABLE `sub_cat` (
  `sub_cat_id` int(11) NOT NULL,
  `sub_cat_ref` varchar(255) NOT NULL,
  `sub_cat_name` varchar(255) NOT NULL,
  `sub_cat_image_url` varchar(255) NOT NULL,
  `popular_cat_value` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sub_cat`
--

INSERT INTO `sub_cat` (`sub_cat_id`, `sub_cat_ref`, `sub_cat_name`, `sub_cat_image_url`, `popular_cat_value`) VALUES
(1, '1', 'testSubCat', 'testSub.jpg', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `user_password` varchar(255) NOT NULL,
  `date_of_birth` date DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `pic_url` varchar(250) DEFAULT NULL,
  `phone` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `user_name`, `user_email`, `user_password`, `date_of_birth`, `gender`, `pic_url`, `phone`) VALUES
(1, 'Mehedi Hasan', 'meek@test.com', '$2b$10$4j3QBtf3qa9pmZGu1BlA0OJP7TizbXeYGRPzGUCMQ7.wawTjUfL96', '2023-09-25', 'male', 'http://localhost:3000/images/userImg/Screenshot 2023-09-13 164622.png', '+8801747090362'),
(13, 'Khaleed Saifullah', 'abc@gmail.com', '$2b$10$hnKdrdscq3IED66UHbpHueN6ksUO8kkJw61Bm9c2WuJZqVg8MofIy', '0000-00-00', 'Male', 'https://mark-agro.soykothosen.com/images/userImg/profile-photo.JPG', '01323719171');

-- --------------------------------------------------------

--
-- Table structure for table `wishlist`
--

CREATE TABLE `wishlist` (
  `wishlist_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `wishlist`
--

INSERT INTO `wishlist` (`wishlist_id`, `user_id`, `product_id`) VALUES
(7, 1, 1),
(10, 13, 1),
(11, 13, 2),
(13, 1, 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `extra_cat`
--
ALTER TABLE `extra_cat`
  ADD PRIMARY KEY (`extra_cat_id`);

--
-- Indexes for table `flashsell`
--
ALTER TABLE `flashsell`
  ADD PRIMARY KEY (`flashSell_id`);

--
-- Indexes for table `main_cat`
--
ALTER TABLE `main_cat`
  ADD PRIMARY KEY (`main_cat_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `order_details`
--
ALTER TABLE `order_details`
  ADD PRIMARY KEY (`order_details_id`);

--
-- Indexes for table `payment_method`
--
ALTER TABLE `payment_method`
  ADD PRIMARY KEY (`payment_method_id`);

--
-- Indexes for table `payment_types`
--
ALTER TABLE `payment_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `product_image`
--
ALTER TABLE `product_image`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_video`
--
ALTER TABLE `product_video`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `status`
--
ALTER TABLE `status`
  ADD PRIMARY KEY (`status_id`);

--
-- Indexes for table `sub_cat`
--
ALTER TABLE `sub_cat`
  ADD PRIMARY KEY (`sub_cat_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD PRIMARY KEY (`wishlist_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `extra_cat`
--
ALTER TABLE `extra_cat`
  MODIFY `extra_cat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=457;

--
-- AUTO_INCREMENT for table `flashsell`
--
ALTER TABLE `flashsell`
  MODIFY `flashSell_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `main_cat`
--
ALTER TABLE `main_cat`
  MODIFY `main_cat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=73;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=75;

--
-- AUTO_INCREMENT for table `order_details`
--
ALTER TABLE `order_details`
  MODIFY `order_details_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=92;

--
-- AUTO_INCREMENT for table `payment_method`
--
ALTER TABLE `payment_method`
  MODIFY `payment_method_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `payment_types`
--
ALTER TABLE `payment_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=177;

--
-- AUTO_INCREMENT for table `product_image`
--
ALTER TABLE `product_image`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=271;

--
-- AUTO_INCREMENT for table `product_video`
--
ALTER TABLE `product_video`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `status`
--
ALTER TABLE `status`
  MODIFY `status_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `sub_cat`
--
ALTER TABLE `sub_cat`
  MODIFY `sub_cat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=96;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `wishlist`
--
ALTER TABLE `wishlist`
  MODIFY `wishlist_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
